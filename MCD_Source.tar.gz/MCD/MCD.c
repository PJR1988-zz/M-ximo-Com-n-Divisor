#include </opt/MCD/hola.h>
#include </opt/MCD/adios.h>
#include </opt/MCD/ejecucion.h>
#include <stdio.h>
#include <stdlib.h>

int main(){

	hola();

	printf("\nPrograma que Calcula el maximo comun divisor de un grupo de numeros dado.");

	ejecucion();

	adios();

	return 0;

}
