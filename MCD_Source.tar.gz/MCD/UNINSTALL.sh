sudo rm /usr/bin/MCD
rm ~/.local/share/applications/MCD.desktop
rm -R ~/.MCD/
rm ~/Escritorio/MCD.desktop
sudo rm /usr/share/applications/MCD.desktop
sudo rm /usr/bin/UNINSTALL_MCD.sh
rm ~/Escritorio/MCD.desktop
sudo rm /usr/share/applications/MCD_Uninstall.desktop
sudo rm /usr/share/pixmaps/MCD.png
